from random import randint, shuffle

gain = 0
for i in range(10000):
    a = randint(1, 2 ** 63 + 1)
    b = a * 2
    boxes = [a, b]
    shuffle(boxes)
    gain += (boxes[0] - boxes[1])

print(gain / 10000)
