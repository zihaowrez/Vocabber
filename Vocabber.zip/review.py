from tkinter import *
from tkinter import ttk
from random import *
from datetime import *
from PIL import Image, ImageTk
from time import sleep

seed(123)

THEME_FONT = 'Comic Sans MS'
BOX_FONT = '微软雅黑'

def remove_space(s):
    while s and s[0] == ' ':
        s = s[1:]
    while s and s[-1] == ' ' :
        s = s[:-1]
    return s

def read_vocab_file(path):
    f = open(path, 'r', encoding = 'utf-16')
    vocabs = f.read().split(sep = '\n')
    f.close()
    words = []
    parts = []
    meanings = []
    familiarity = []
    wrongs = []
    times = []
    lasts = []
    for i in range(len(vocabs) - 1):
        v = vocabs[i].split(sep = '\t')
        words.append(v[0])
        parts.append(v[1])
        meanings.append(v[2])
        familiarity.append(int(v[3]))
        wrongs.append(int(v[4]))
        times.append(datetime.strptime(v[5], '%Y-%m-%d'))
        lasts.append(int(v[6]))
        
    return words, parts, meanings, familiarity, wrongs, times, lasts

def how_to_review(lang):

    def back_home():
        frame.destroy()
        home_frame = home()
        home_frame.pack(fill = 'both', expand = True)
        return home_frame

    def review(lang, scope):
        frame.destroy()
        review_frame = review_vocab(lang, scope)
        review_frame.pack(fill = 'both', expand = True)
        return review_frame

    if lang:

        words, parts, meanings, familiarity, wrongs, times, lasts = read_vocab_file('d:/02 Documents/Programming/CPython/Vocabber/' + lang + '.txt')
        n = len(words)
        
        frame = Frame(window)

        title = Label(frame, text = 'Choose your scope', font = ('Comic Sans MS', 20))
        title.place(x = 320, y = 70, anchor = 'center')

        language_lbl = Label(frame, text = 'Current language: ' + lang,
                             font = ('Comic Sans MS', 14), fg = 'red')
        language_lbl.place(x = 320, y = 110, anchor = 'center')
        
        all_btn = Button(frame, text = 'All words', font = ('Comic Sans MS', 14),
                           command = lambda: review(lang, range(n)))
        all_btn.place(x = 180, y = 180, anchor = 'w')
        all_lbl = Label(frame, text = str(n) + ' words', font = (THEME_FONT, 14))
        all_lbl.place(x = 420, y = 180, anchor = 'w')

        now = datetime.strptime(datetime.now().strftime('%Y-%m-%d'), '%Y-%m-%d')
        recent_scope = [i for i in range(n) if (now - times[i]).days < 8]
        recent_btn = Button(frame, text = 'Recent words', font = ('Comic Sans MS', 14),
                              command = lambda: review(lang, recent_scope))
        recent_btn.place(x = 180, y = 240, anchor = 'w')
        recent_lbl = Label(frame, text = str(len(recent_scope)) + ' words', font = (THEME_FONT, 14))
        recent_lbl.place(x = 420, y = 240, anchor = 'w')

        unfamil_scope = [i for i in range(n) if familiarity[i] < 3]
        unfamil_btn = Button(frame, text = 'Unfamiliar words', font = ('Comic Sans MS', 14),
                             command = lambda: review(lang, unfamil_scope))
        unfamil_btn.place(x = 180, y = 300, anchor = 'w')
        unfamil_lbl = Label(frame, text = str(len(unfamil_scope)) + ' words', font = (THEME_FONT, 14))
        unfamil_lbl.place(x = 420, y = 300, anchor = 'w')

        back = Button(frame, text = 'Back', font = (THEME_FONT, 14), bd = 2,
                       command = lambda: back_home().tkraise())
        back.place(x = 540, y = 40)
        
        frame.pack(fill = 'both', expand = True)
        
        return frame
        
    else:
        return back_home()

def review_vocab(lang, scope, counts = None, *shown):

    frame = Frame(window)
    
    if lang:

        def back_home():
            frame.destroy()
            home_frame = home()
            home_frame.pack(fill = 'both', expand = True)
            return home_frame

        def show_next():
            frame.destroy()
            next_frame = review_vocab(lang, scope, counts, shown)
            next_frame.pack(fill = 'both', expand = True)
            return next_frame

        def finished():
            frame.destroy()
            finish_frame = Frame(window)
            text = Label(finish_frame, text = 'Congratulations! You\'ve just reviewed ' + '5' +
                         ' words!', font = ('Comic Sans MS', 18))
            text.place(relx = 0.5, rely = 0.3, anchor = 'center')
            
            '''next_word = Button(finish_frame, text = 'Next', font = ('Comic Sans MS', 14),
                               command = lambda: show_next().tkraise())
            next_word.place(x = 240, y = 330)'''

            def cmd():
                def combined():
                    finish_frame.destroy()
                    back_home().tkraise()
                return combined

            back = Button(finish_frame, text = 'Back', font = ('Comic Sans MS', 12), bd = 2,
                           command = cmd())
            back.place(x = 540, y = 30, anchor = 'center')

            finish_frame.pack(fill = 'both', expand = True)
            
            return finish_frame
        
        words, parts, meanings, familiarity, wrongs, times, lasts = read_vocab_file('d:/02 Documents/Programming/CPython/Vocabber/' + lang + '.txt')
        n = len(words)

        if shown:
            shown = shown[0]
        else:
            shown = dict()
            for i in scope:
                shown[i] = False
        not_shown = [i for i in shown.keys() if not shown[i]]
        correct = choice(not_shown)
        shown[correct] = 1
        items = [correct]
        while len(items) < min(6, n):
            other = choice(range(n))
            while other in items:
                other = choice(range(n))
            items.append(other)
        
        shuffle(items)
            
        title = Label(frame, text = words[correct], font = ('Comic Sans MS', 24))
        title.place(x = 320, y = 120, anchor = 'center')

        if not counts:
            counts = [0, 0]

        count1 = Label(frame, text = str(sum(counts)) + ' reviewed - ')
        count2 = Label(frame, text = str(counts[0]) + ' correct, ', fg = 'green')
        count3 = Label(frame, text = str(counts[1]) + ' incorrect', fg = 'red')
        count1.place(x = 20, y = 20)
        count2.place(x = 100, y = 20)
        count3.place(x = 160, y = 20)
        
        options = []
        selected = [0]
        
        def sel_correct():

            if not selected[0]:
                selected[0] = 1
                if lasts[correct] == 0:
                    familiarity[correct] += 1
                else:
                    familiarity[correct] += 2
                if lasts[correct] == 0:
                    lasts[correct] = 1
                counts[0] += 1
                scr = familiarity[correct]
                text = 'Familiarity: ' + str(scr)
                if scr > 0:
                    score = Label(frame, text = text, fg = 'green')
                elif scr == 0:
                    score = Label(frame, text = text)
                else:
                    score = Label(frame, text = text, fg = 'red')
                score.place(x = 320, y = 180, anchor = 'center')
            
                f = open(PATH + lang + '.txt', 'w', encoding = 'utf-16')
                for j in range(len(words)):
                    f.write(words[j] + '\t' + parts[j] + '\t' + meanings[j] + '\t'
                            + str(familiarity[j]) + '\t' + str(wrongs[j]) + '\t'
                            + times[j].strftime('%Y-%m-%d') + '\t' + str(lasts[j]) + '\n')
                f.close()
            
                if len(not_shown) > 1:
                    frame.after(1500, None)
                else:
                    finished
                return show_next()
                
        def sel_wrong(i):

            if not selected[0]:
                selected[0] = 1
                familiarity[correct] -= 1
                lasts[correct] = 0
                wrongs[correct] += 1
                counts[1] += 1
                scr = familiarity[correct]
                text = 'Familiarity: ' + str(scr)
                if scr > 0:
                    score = Label(frame, text = text, fg = 'green')
                elif scr == 0:
                    score = Label(frame, text = text)
                else:
                    score = Label(frame, text = text, fg = 'red')
                score.place(x = 320, y = 180, anchor = 'center')
            
                f = open(PATH + lang + '.txt', 'w', encoding = 'utf-16')
                for j in range(len(words)):
                    f.write(words[j] + '\t' + parts[j] + '\t' + meanings[j] + '\t'
                            + str(familiarity[j]) + '\t' + str(wrongs[j]) + '\t'
                            + times[j].strftime('%Y-%m-%d') + '\t' + str(lasts[j]) + '\n')
                f.close()

                options[cr].config(bg = 'palegreen')
                if len(not_shown) > 1:
                    frame.after(2500, None)
                else:
                    finished

                return show_next()

        for i in range(len(items)):
            item = meanings[items[i]]
            
            if parts[items[i]]:
                item = parts[items[i]] + ' ' + item
            if items[i] == correct:
                cr = i
                options.append(Button(frame, text = item, font = ('Comic Sans MS', 13),
                                      command = lambda: sel_correct().tkraise()))
            else:
                options.append(Button(frame, text = item, font = ('Comic Sans MS', 13),
                                      command = lambda i = i: sel_wrong(i).tkraise()))

            options[i].place(x = 330 - 90 * ((len(items) + 1) // 2) + 180 * (i // 2),
                             y = 300 + 80 * (i % 2), anchor = 'w')
        
        '''next_word = Button(frame, text = 'Next', font = ('Comic Sans MS', 14),
                           command = lambda: show_next(lang, shown).tkraise())
        next_word.place(x = 520, y = 270)

        def show_next_key(event = None):
            show_next(lang, shown).tkraise()
        next_word.bind('<Return>', show_next_key)
        next_word.focus()'''

        def mark():
            pass
        
        render = ImageTk.PhotoImage(Image.open(PATH + 'unmarked.png'))
        unmarked = Label(frame, image = render)
        unmarked.image = render
        unmarked.place(x = 540, y = 120, anchor = 'center')
        unmarked.bind('<ButtonRelease-1>', mark)
        
        back = Button(frame, text = 'Back', font = ('Comic Sans MS', 14), bd = 2,
                       command = lambda: back_home().tkraise())
        back.place(x = 540, y = 30)

        frame.pack(fill = 'both', expand = True)
        return frame
    
    else:
        return back_home()

PATH = 'd:/02 Documents/Programming/CPython/Vocabber/'

file = open(PATH + 'initialize.txt', 'r', encoding = 'utf-16')
langs = file.read()
if langs:
    langs = langs.split(sep = '\n')
    while(langs[-1] == ''):
        del(langs[-1])
else:
    langs = []

window = Tk()
window.title('Vocabber')
window.geometry('640x480+20+20')

def home():

    frame = Frame(window)

    title = Label(frame, text = 'Vocabber', font = (THEME_FONT, 26))
    title.place(x = 320, y = 70, anchor = 'center')

    text1 = Label(frame, text = 'Select a language: ', font = (THEME_FONT, 14))
    text1.place(x = 40, y = 140)

    lang_seln = Listbox(frame, height = 8, width = 20,
                        selectmode = 'Single', selectbackground = 'blue')
    for lang in langs:
        lang_seln.insert(END, lang)
    lang_seln.place(x = 210, y = 145)
    lang_seln.focus()
    lang_seln.select_set(0)

    def onKey(key):
        lang_seln.select_clear(0, END)
        if key.keycode == 40:
            lang_seln.select_set(min(lang_seln.index(ACTIVE) + 1, len(langs) - 1))
        elif key.keycode == 38:
            lang_seln.select_set(max(lang_seln.index(ACTIVE) - 1, 0))
        else:
            lang_seln.select_set(ACTIVE)

    lang_seln.bind('<Key>', onKey)

    def to_revVoc(lang):
        frame.destroy()
        return how_to_review(lang)

    review = Button(frame, text = 'Review words', font = (THEME_FONT, 13), bd = 3,
                    command = lambda: to_revVoc(lang_seln.get(ACTIVE)).tkraise())
    review.place(x = 380, y = 190)
    
    return frame


home_frame = home()
home_frame.pack(fill = 'both', expand = True)

window.mainloop()
